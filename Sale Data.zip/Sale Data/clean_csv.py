input_file = 'Customers_1.csv'
output_file = 'clean_file.csv'

with open(input_file, 'r', encoding='utf-8', errors='ignore') as f_in:
    with open(output_file, 'w', encoding='utf-8') as f_out:
        for line in f_in:
            f_out.write(line)
